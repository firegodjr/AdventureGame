﻿using RPGFinal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RPG_Final
{
    public static class Command
    {
        public static Directions move = Directions.NONE;

        private static Floor1 f1 = new Floor1();
        private static Floor2 f2 = new Floor2();

        /// <summary>
        /// Gets the user input
        /// </summary>
        /// <param name="player"></param>
        public static void Input(Player_Stats player)
        {
            move = Directions.NONE;
            TextWriter.Write($"Health: %2{player.health}%0 - Strength: %4{player.strength}%0 - Hunger: %4{player.hunger}%0 - Gold: %5{player.money}%0");
            TextWriter.Write("\n%1>>>%0");
            string input = Console.ReadLine();
            if (string.IsNullOrEmpty(input))
            {
                TextWriter.Write("Error, What you entered is not acceptable. You haven't entered anything. Try again.\n");
            }
            else
            {
                input = input.ToUpper();
                switch (input)
                {
                    case "?":
                    case "HELP":
                        Help();
                        break;
                    case "SOUTH":
                    case "S":
                        move = Directions.SOUTH;
                        break;
                    case "E":
                    case "EAST":
                        move = Directions.EAST;
                        break;
                    case "WEST":
                    case "W":
                        move = Directions.WEST;
                        break;
                    case "N":
                    case "NORTH":
                        move = Directions.NORTH;
                        break;
                    case "BUY":
                    case "B":
                        Buy(player, Program.game);
                        break;
                    case "CONSUME":
                    case "C":
                        QueryFood(player);
                        break;
                    case "EXIT":
                    case "STOP":
                        TextWriter.Write("%5Are you sure you wish to quit? The game will be saved.%0 (Y/n)\n");
                        char quit = Console.ReadKey().KeyChar;
                        if (quit == 'y' || quit == 'Y')
                        {
                            Program.SaveGame();
                            Environment.Exit(0);
                        }
                        break;
                    case "PS":
                    case "STATS":
                    case "PLAYERSTATS":
                        Stats(player);
                        break;
                    case "INVENTORY":
                    case "I":
                        CheckInventory(player);
                        break;
                    case "~god":
                        Fix(player);
                        break;
                    case "HEAL":
                    case "H":
                        QueryHealthPotion(player);
                        break;
                    case "M":
                    case "Map":
                        DisplayMap(player);
                        break;
                    default:
                        TextWriter.Write("Invalid input. Type '%4?%0' for help.");
                        break;
                }
            }
        }

        //gets player stats
        public static void Stats(Player_Stats player)
        {
            int strength = player.strength;
            int money = player.money;
            int hunger = player.hunger;
            int health = player.health;
            int defense = player.defense;

            TextWriter.Write("Health:%3\t" + health+"%0\n"+
                "Strength:%3\t" + strength + "%0\n" +
                "Hunger:%3\t" + hunger + "%0\n" +
                "Money:%3\t" + money + "%0\n" +
                "Defense:%3\t" + defense + "%0\n");
        }

        /// <summary>
        /// Lists the player inventory and allows equipping weapons
        /// </summary>
        /// <param name="player"></param>
        public static void CheckInventory(Player_Stats player)
        {
            for (int x = 0; x < player.inv.Count; x++)
            {
                int itemtype = (int)player.inv[x].type;
                string metatype = "";
                switch(itemtype)
                {
                    case (int)ItemTypes.FOOD:
                        metatype = "%3-{0} hunger%0";
                        break;
                    case (int)ItemTypes.HEALTH:
                        metatype = "%3+{0} health%0";
                        break;
                    case (int)ItemTypes.WEAPON:
                        metatype = "%2+{0} damage%0";
                        break;
                }

                TextWriter.Write($"{Enum.GetNames(typeof(ItemTypes))[itemtype]} {player.inv[x].name} - {string.Format(metatype, player.inv[x].metadata)}");
            }

            TextWriter.Write("Want to equip a weapon? (Y/n)");

            string input = Console.ReadKey().KeyChar.ToString().ToLower();

            switch(input)
            {
                case "y":
                    TextWriter.Write("\nWhich weapon would you like to equip? (Write out the name)\n");
                    string weaponname = Console.ReadLine();
                    if(player.GetItemCount(weaponname) > 0 && Program.game.GetItemFromName(weaponname).type == ItemTypes.WEAPON)
                    {
                        player.RemoveItem(weaponname);
                        player.EquippedWeapon = Program.game.GetItemFromName(weaponname);
                        TextWriter.Write($"%4{player.EquippedWeapon.name}%0 equipped!");
                    }
                    else
                    {
                        TextWriter.Write("%2You can't equip that.");
                    }
                    break;
            }
        }

        /// <summary>
        /// Launches area map program
        /// </summary>
        /// <param name="player"></param>
        public static void DisplayMap(Player_Stats player)
        {
            if (player.GetItemCount("Map") != 0)
            {
                Console.WriteLine("Press F to open first floor map, S to open second floor map.");
                string map = Console.ReadKey(true).KeyChar.ToString();
                Floor1 f1 = new Floor1();
                Floor2 f2 = new Floor2();
                if (map == "F" || map == "f")
                {
                    Thread mapthread = new Thread(new ThreadStart(FirstFloorMap));
                    mapthread.Start();
                }
                else if (map == "S" || map == "s")
                {
                    Thread mapthread = new Thread(new ThreadStart(SecondFloorMap));
                    mapthread.Start();
                }
                else
                {
                    Console.WriteLine("You have entered an incorrect letter.");
                    Console.ReadKey();
                }
            }
            else
            {
                TextWriter.Write("You do not have a map. To get one buy one from the shop");
            }
        }

        private static void FirstFloorMap()
        {
            System.Windows.Forms.Application.Run(f1);
        }

        private static void SecondFloorMap()
        {
            System.Windows.Forms.Application.Run(f2);
        }

        /// <summary>
        /// Displays help text
        /// </summary>
        public static void Help()
        {
            TextWriter.Write("To move South type '%4S%0'. \nTo move East type '%4E%0'. \nTo move West type '%4W%0'. \nTo move North type '%4N%0'. \nTo buy stuff type '%4B%0'. \nTo eat food type '%4C%0'. \nTo Exit the game type '%4exit%0' or '%4stop%0'. \nTo get player stats type '%4ps%0' or '%4stats%0'. \nTo check your Inventory type '%4I%0'. \n To look at the map type '%4M%0'.\n\nPress any key to continue", 10);
            Console.ReadKey(true);
        }


        /// <summary>
        /// Allows player to eat some food
        /// </summary>
        /// <param name="player"></param>
        public static void QueryFood(Player_Stats player)
        {
            string foodInput = "";
            TextWriter.Write("Which food would you like to consume?");

            List<string> itemsAlreadyWritten = new List<string>();
            foreach(Item i in player.inv)
            {
                if(i.type == ItemTypes.FOOD && !itemsAlreadyWritten.Contains(i.name))
                {
                    TextWriter.Write($"%5{i.name}%0 %3+{i.metadata} hunger%0 (You have {player.GetItemCount(i.name)})");
                    itemsAlreadyWritten.Add(i.name);
                }
            }

            Console.WriteLine();
            foodInput = Console.ReadLine().ToLower();
            Item eatenItem = Program.game.GetItemFromName(foodInput);
            if(eatenItem != null)
            {
                if (player.GetItemCount(eatenItem.name) > 0 && eatenItem.type == ItemTypes.FOOD)
                {
                    player.RemoveItem(eatenItem.name);
                    TextWriter.Write($"%3Delicious! You recover {eatenItem.metadata} hunger!%0");
                    player.hunger += eatenItem.metadata;
                    if(player.hunger > 100)
                    {
                        player.hunger = 100;
                        TextWriter.Write("%5Your hunger is maxed out!%0");
                    }
                }
                else if (eatenItem.type != ItemTypes.FOOD)
                {
                    TextWriter.Write("You can't eat things that aren't food. Unless you're Nick.");
                }
                else
                {
                    TextWriter.Write("You don't have any of those to eat.");
                }
            }
            else
            {
                TextWriter.Write($"Not only do you not have any, but '{foodInput}' isn't even an item in the game. Sorry.");
            }
            
        }

        /// <summary>
        /// Allows the player to chug a health potion, increasing health up to a cap of 125 health
        /// </summary>
        /// <param name="player"></param>
        public static void QueryHealthPotion(Player_Stats player)
        {
            string Healinput = "";
            TextWriter.Write("Would you like to use a health potion? Press %4y%0 to confirm.\n");
            Healinput = Console.ReadKey(true).KeyChar.ToString().ToLower();
            if (Healinput == "y")
            {
                TextWriter.Write($"%3*slurp*`\n+20 Health!%0\n");
                if (player.RemoveItem("health potion"))
                {
                    player.health += 20;
                    if(player.health > 125)
                    {
                        player.health = 125;
                        TextWriter.Write("%5Health is maxed out!%0");
                    }
                }
            }
        }

        //opens the user shop 
        public static void Buy(Player_Stats ps, Game game)
        {
            TextWriter.Write(
                "What would you like to buy?\n\n" +
                "%1Item Name\tCost\tEffects%0\n" +
                "1\\.Wood Sword\t %5$25%0\t%2+5atk%0\n" +
                "2\\.Iron Sword\t %5$100%0\t%2+10atk%0\n" +
                "3\\.Master Sword\t %5$160%0\t%2+15atk%0\n" +
                "4\\.Necreant Blade %5$225%0\t%2+25atk%0\n" +
                "5\\.Health Potion\t %5$20%0\t%4+20 Health on Use%0\n" +
                "6\\.Apple\t\t %5$5%0\t%4+5 Hunger on Consumption%0\n" +
                "7\\.Bread\t\t %5$15%0\t%4+20 Hunger on Consumption%0\n" +
                "8\\.Area Map\t %5$120%0\t%4View the area map with 'M'%0\n" +
                $"\nYou have %5{ps.money} gold%0.\n" +
                "%3Type the number of the item to purchase it%0" +
                "Press any other key to exit the shop.\n", 10);

            int input = Convert.ToInt32(char.GetNumericValue(Console.ReadKey(true).KeyChar));

            switch(input)
            {
                case 1:
                    PurchaseItem(ps, game.GetItemFromName("wooden sword"), 25);
                    break;
                case 2:
                    PurchaseItem(ps, game.GetItemFromName("iron sword"), 100);
                    break;
                case 3:
                    PurchaseItem(ps, game.GetItemFromName("master sword"), 160);
                    break;
                case 4:
                    PurchaseItem(ps, game.GetItemFromName("necreant blade"), 225);
                    break;
                case 5:
                    PurchaseItem(ps, game.GetItemFromName("health potion"), 20);
                    break;
                case 6:
                    PurchaseItem(ps, game.GetItemFromName("apple"), 5);
                    break;
                case 7:
                    PurchaseItem(ps, game.GetItemFromName("bread"), 15);
                    break;
                case 8:
                    PurchaseItem(ps, game.GetItemFromName("map"), 120);
                    break;
            }

            Console.WriteLine();
        }

        //user input
        public static void Fix(Player_Stats player)
        {
            //12,126,21
            TextWriter.Write("you know what to do");
            string input = Console.ReadLine();
            if (input == "m")
            {
                player.money += 100;
            }
            else if (input == "s")
            {
                player.strength += 100;
            }
            else if (input == "h")
            {
                player.health += 100;
            }
            else if (input == "e")
            {
                player.hunger += 100;
            } 
        }

        private static void PurchaseItem(Player_Stats ps, Item item, int cost)
        {
            if(ps.money >= cost)
            {
                ps.money -= cost;
                ps.inv.Add(item);
                TextWriter.Write($"%5{cost}%0 gold removed.");
                TextWriter.Write($"You got the %4{item.name}%0!`");
            }
            else
            {
                TextWriter.Write("You don't have enough gold, sorry!`");
            }
        }
    }
}
