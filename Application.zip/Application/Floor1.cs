﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPG_Final.Application
{
    public partial class Floor1 : Form
    {
        public Floor1()
        {
            InitializeComponent();
        }
    }
}
